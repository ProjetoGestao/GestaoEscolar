 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.modelo;


import java.sql.Connection;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import projetogestaoescolar.GerenciarPeriodo;
import projetogestaoescolarDao.PeriodoDAO;

/**
 *
 * @author Gustavo
 */
public class GerenciamentoDePeriodo {

   
    
    GerenciarPeriodo gerenciarPeriodo;
    Periodo periodo;
    PeriodoDAO dao;
    boolean edit = false;
            
     public GerenciamentoDePeriodo(GerenciarPeriodo tela,Connection conexao) {
        gerenciarPeriodo = tela;
        periodo = new Periodo();
        dao = new  PeriodoDAO(conexao);
        modelo = (DefaultTableModel)gerenciarPeriodo.getjTable1().getModel();
    }
    
    int receberIdPeriodo;
    String idPeriodo;
    int receberAno;
    String ano;
    int receberDiasLetivos;
    String diasLetivos;
     private DefaultTableModel modelo;
    
    public void salvar(GerenciarPeriodo gerenciarPeriodo){
        if(edit == false){
        receberIdPeriodo = Integer.parseInt(gerenciarPeriodo.getjTextField1().getText());
        periodo.setIdPeriodo(receberIdPeriodo);
        ano = gerenciarPeriodo.getjTextField2().getText();
        receberAno = Integer.parseInt(ano);
        periodo.setAno(receberAno);
        diasLetivos = gerenciarPeriodo.getjTextFieldQuantDias().getText();
        receberDiasLetivos = Integer.parseInt(diasLetivos);
        periodo.setDiasLetivos(receberDiasLetivos);
        dao.adiciona(periodo);
     }
        else{
            receberIdPeriodo = Integer.parseInt(gerenciarPeriodo.getjTextField1().getText());
            periodo.setIdPeriodo(receberIdPeriodo);
            ano = gerenciarPeriodo.getjTextField2().getText();
            receberAno = Integer.parseInt(ano);
            periodo.setAno(receberAno);
            diasLetivos = gerenciarPeriodo.getjTextFieldQuantDias().getText();
            receberDiasLetivos = Integer.parseInt(diasLetivos);
            periodo.setDiasLetivos(receberDiasLetivos);
            dao.altera(periodo);
        }
        this.gerenciarPeriodo.getjTextField1().setEnabled(true);
        this.gerenciarPeriodo.limpaCampos();
    }
    
    public void listar(GerenciarPeriodo gerenciarPeriodo){
        limpaTabela();   
        List<Periodo> listaPessoas = dao.lista();
        for(int i=0;i<listaPessoas.size();i++){
            addTabela(
                    listaPessoas.get(i).getIdPeriodo(),
                    listaPessoas.get(i).getAno(),
                    listaPessoas.get(i).getDiasLetivos()
                    );
        }
        
    }
    
    public void editaDados(){
        int item = gerenciarPeriodo.itemSelecionado();
        if(item>=0){
            gerenciarPeriodo.getjTextField1().setText(String.valueOf(gerenciarPeriodo.getjTable1().getValueAt(item, 0)));
            gerenciarPeriodo.getjTextField1().setEnabled(false);
            gerenciarPeriodo.getjTextField2().setText(String.valueOf( gerenciarPeriodo.getjTable1().getValueAt(item, 1)));
            gerenciarPeriodo.getjTextFieldQuantDias().setText(String.valueOf(gerenciarPeriodo.getjTable1().getValueAt(item, 2)));
            edit = true;
        }
    }
    
    public void excluir(){
        int item = gerenciarPeriodo.itemSelecionado();
        dao.exclui((int)gerenciarPeriodo.getjTable1().getValueAt(item, 0));
    }
    
    
    private void limpaTabela(){
        int linhas = modelo.getRowCount();
        for(int i=0;i<linhas;i++){
            modelo.removeRow(0);
        }
    }
    
    public final void addTabela(Object... objects) {
        modelo.addRow(objects);
    }
    
    
    
   
    
}
