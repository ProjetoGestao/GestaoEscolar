package projetogestaoescolar.modelo;

public class RelacionamentoDisciplinaTurmaProfessor {
    
    int nMatricula;
    int idTurma;
    int idCodigo;

    public RelacionamentoDisciplinaTurmaProfessor(int nMatricula, int idTurma, int idCodigo) {
        this.nMatricula = nMatricula;
        this.idTurma = idTurma;
        this.idCodigo = idCodigo;
    }

    public int getnMatricula() {
        return nMatricula;
    }

    public int getIdTurma() {
        return idTurma;
    }

    public int getIdCodigo() {
        return idCodigo;
    }
    
    
    
}
