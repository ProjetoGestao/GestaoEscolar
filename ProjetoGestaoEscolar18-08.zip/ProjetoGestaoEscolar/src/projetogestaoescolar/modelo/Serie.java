package projetogestaoescolar.modelo;

class Serie {
    
    int ano; // 1 (primeiro ano) , 2 (segundo ano) ...
    int quantidadeDeTurmas;
    String nivel; // fundamental, médio..
    
    public Serie(int ano, int quantidadeDeTurmas, String nivel) {
        this.ano = ano;
        this.quantidadeDeTurmas = quantidadeDeTurmas;
        this.nivel = nivel;
    }
    
    public void setAno(int ano) {
        this.ano = ano;
    }

    public void setQuantidadeDeTurmas(int quantidadeDeTurmas) {
        this.quantidadeDeTurmas = quantidadeDeTurmas;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public int getAno() {
        return ano;
    }

    public int getQuantidadeDeTurmas() {
        return quantidadeDeTurmas;
    }

    public String getNivel() {
        return nivel;
    }
    
}
