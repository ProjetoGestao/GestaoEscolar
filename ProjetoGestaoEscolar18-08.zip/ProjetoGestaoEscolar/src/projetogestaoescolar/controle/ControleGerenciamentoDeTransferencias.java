/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import projetogestaoescolar.GerenciamentoDeTransferencias;

/**
 *
 * @author Gustavo
 */
public class ControleGerenciamentoDeTransferencias implements ActionListener{
    GerenciamentoDeTransferencias gerenciamentoDeTransferencias;
    
       public ControleGerenciamentoDeTransferencias(){
        carregaTelas();
        adicionaEventos();
    }
    
    private void carregaTelas(){
        gerenciamentoDeTransferencias = new GerenciamentoDeTransferencias();
        gerenciamentoDeTransferencias.setVisible(true);
    }
    
    public void adicionaEventos(){
        gerenciamentoDeTransferencias.getjButtonListar().addActionListener(this);
        gerenciamentoDeTransferencias.getjButtonPesquisar().addActionListener(this);
        gerenciamentoDeTransferencias.getjButtonRecebeAluno().addActionListener(this);
        gerenciamentoDeTransferencias.getjButtonTransferir().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == gerenciamentoDeTransferencias.getjButtonListar()){
            
    }
        if(e.getSource() == gerenciamentoDeTransferencias.getjButtonPesquisar()){
            
        }
        if(e.getSource() == gerenciamentoDeTransferencias.getjButtonRecebeAluno()){
            
        }
        if(e.getSource() == gerenciamentoDeTransferencias.getjButtonTransferir()){
            
        }
    
    }
}
