/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.modelo;

import java.sql.Connection;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import projetogestaoescolar.GerenciarPeriodo;
import projetogestaoescolarDao.PeriodoDAO;

/**
 *
 * @author Gustavo
 */
public class GerenciamentoDePeriodo {

   
    
    GerenciarPeriodo gerenciarPeriodo;
    Periodo periodo;
    PeriodoDAO dao;
            
     public GerenciamentoDePeriodo(GerenciarPeriodo tela) {
        Connection conexao = null;
        gerenciarPeriodo = tela;
        periodo = new Periodo();
        dao = new  PeriodoDAO(conexao);
        modelo = (DefaultTableModel)gerenciarPeriodo.getjTable1().getModel();
    }
    
    int receberIdPeriodo;
    String idPeriodo;
    int receberAno;
    String ano;
    int receberDiasLetivos;
    String diasLetivos;
     private DefaultTableModel modelo;
    
    public void salvar(GerenciarPeriodo gerenciarPeriodo){
        receberIdPeriodo = Integer.parseInt(gerenciarPeriodo.getjTextField1().getText());
        periodo.setIdPeriodo(receberIdPeriodo);
        ano = gerenciarPeriodo.getjTextField2().getText();
        receberAno = Integer.parseInt(ano);
        periodo.setAno(receberAno);
        diasLetivos = gerenciarPeriodo.getjTextFieldQuantDias().getText();
        receberDiasLetivos = Integer.parseInt(diasLetivos);
        periodo.setDiasLetivos(receberDiasLetivos);
        dao.adiciona(periodo);
     }
    
    public void listar(GerenciarPeriodo gerenciarPeriodo){
        limpaTabela();   
        List<Periodo> listaPessoas = dao.lista();
        for(int i=0;i<listaPessoas.size();i++){
            addTabela(
                    listaPessoas.get(i).getIdPeriodo(),
                    listaPessoas.get(i).getAno(),
                    listaPessoas.get(i).getDiasLetivos()
                    );
        }
        
    }
    
    private void limpaTabela(){
        int linhas = modelo.getRowCount();
        for(int i=0;i<linhas;i++){
            modelo.removeRow(0);
        }
    }
    
    public final void addTabela(Object... objects) {
        modelo.addRow(objects);
    }
    
    
}
