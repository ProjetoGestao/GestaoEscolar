/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import projetogestaoescolar.GerenciarPeriodo;
import projetogestaoescolar.modelo.GerenciamentoDePeriodo;
import projetogestaoescolar.modelo.Periodo;
import projetogestaoescolarDao.PeriodoDAO;

/**
 *
 * @author Gustavo
 */
public class ControleGerenciarPeriodos implements ActionListener {
    GerenciarPeriodo gerenciarPeriodo;
    GerenciamentoDePeriodo gerenciamento;
    PeriodoDAO dao; 
    private Connection conexao;
        
    public ControleGerenciarPeriodos(Connection conexao){
        this.conexao =  conexao;        
        carregaTelas();
        adicionaEventos();   
    }
    
    private void carregaTelas(){
        gerenciarPeriodo = new GerenciarPeriodo();   
        gerenciamento = new GerenciamentoDePeriodo(gerenciarPeriodo,conexao);
        gerenciamento.listar(gerenciarPeriodo);
         gerenciarPeriodo.setVisible(true);
    }

    private void adicionaEventos(){
        gerenciarPeriodo.getjButtonSalvar().addActionListener(this);
        gerenciarPeriodo.getjButtonAlterar().addActionListener(this);
        gerenciarPeriodo.getjButtonExcluir().addActionListener(this);
    
    }
    
  
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == gerenciarPeriodo.getjButtonSalvar()){
            gerenciamento.salvar(gerenciarPeriodo);
            gerenciamento.listar(gerenciarPeriodo);
        }
        if(e.getSource() == gerenciarPeriodo.getjButtonAlterar()){
            gerenciamento.editaDados();
            gerenciamento.listar(gerenciarPeriodo);
        }
        if(e.getSource() == gerenciarPeriodo.getjButtonExcluir()){
            gerenciamento.excluir();
            gerenciamento.listar(gerenciarPeriodo);
        }
            
    }
    

    
    
}
