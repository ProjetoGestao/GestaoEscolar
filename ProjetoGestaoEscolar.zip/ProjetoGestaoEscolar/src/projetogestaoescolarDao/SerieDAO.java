/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolarDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import projetogestaoescolar.GerenciarSeries;
import projetogestaoescolar.modelo.Serie;

/**
 *
 * @author gustavo.martins
 */
public class SerieDAO {
    private Connection conexao;
    private DefaultTableModel modelo;
    private int id;
    private GerenciarSeries gerenciar;
    
    public SerieDAO(Connection conexao){
        this.conexao = conexao;
    }
    
    public void adiciona(Serie serie){
        
        String sql = "insert into serie(ano, quantidadeDeTurmas, nivel)" + "values (?,?,?)";
        try{
            PreparedStatement pst = conexao.prepareStatement(sql);
            pst.setInt(1,serie.getAno());
            pst.setInt(2,serie.getQuantidadeDeTurmas());
            pst.setString(3,serie.getNivel());
            pst.execute();
            pst.close();
        }catch (SQLException e){
            JOptionPane.showMessageDialog(gerenciar,"Não foi possivel inserir");
            throw new RuntimeException(e);
        }
    }
    
    public List<Serie> lista(){
        String sql = "select * from serie order by ano";
        List<Serie> listaSeries = new ArrayList<Serie>();
        try{
            PreparedStatement pst = conexao.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            /*while(){
                
            }*/
        }catch{
           
        }
    }
    
}
