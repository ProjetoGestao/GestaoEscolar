/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import projetogestaoescolar.GerenciarSeries;
import projetogestaoescolar.MenuPrincipal;
import projetogestaoescolar.modelo.Serie;
import projetogestaoescolarDao.SerieDAO;

/**
 *
 * @author Gustavo
 */
public class ControleGerenciarSeries  implements ActionListener{
    GerenciarSeries gerenciarSeries;
    SerieDAO serie;
    private Connection conexao;
    boolean edit = false;
    int id = 0;
    
    public ControleGerenciarSeries(MenuPrincipal menuPrincipal, Connection conexao){
        this.conexao =  conexao;  
        this.serie = new SerieDAO(conexao);
        carregaTelas(menuPrincipal);
        adicionaEventos();
        listarComboBox();
        gerenciarSeries.setVisible(true);
        
        
    }
    
    private void carregaTelas(MenuPrincipal menuPrincipal){
        gerenciarSeries  = new GerenciarSeries(menuPrincipal,true);
        
    }
    
    private void adicionaEventos(){
        gerenciarSeries.getjButtonSalvar().addActionListener(this);
        gerenciarSeries.getjButtonAlterar().addActionListener(this);
        gerenciarSeries.getjButtonExcluir().addActionListener(this);
    }
    
    private void gravaDados(){
        Serie s = new Serie();
        s.setAno((int)gerenciarSeries.getjComboBoxSelecionaAnoLetivo().getSelectedItem());
        s.setNumeroDeTurmas((int)gerenciarSeries.getjComboBoxSelecionaNumeroDaSerie().getSelectedItem());
        s.setQuantidadeDeTurmas((int)gerenciarSeries.getjComboBoxSelecionaQuantidadeTurmas().getSelectedItem());        
        if(edit == false){
            serie.adiciona(s);
        }
        else{
            s.setIdSerie(id);
            serie.alterar(s);
        }
    }
    
    private void editaDados(){
        int item = gerenciarSeries.itemSelecionado();
        if(item>=0){
            gerenciarSeries.getjComboBoxSelecionaAnoLetivo().setSelectedItem(gerenciarSeries.getjTable1().getValueAt(item, 1));
            gerenciarSeries.getjComboBoxSelecionaNumeroDaSerie().setSelectedItem(gerenciarSeries.getjTable1().getValueAt(item, 2));
            gerenciarSeries.getjComboBoxSelecionaQuantidadeTurmas().setSelectedItem(gerenciarSeries.getjTable1().getValueAt(item, 3));
            id = (int)gerenciarSeries.getjTable1().getValueAt(item, 0);
        }
    }
    
    private void listarComboBox(){
        List<Serie> listaSeriesCombox = serie.listaCombobox();
        for(int i =0;i<listaSeriesCombox.size();i++){
            gerenciarSeries.getjComboBoxSelecionaAnoLetivo().addItem(listaSeriesCombox.get(i).getAno());
        }
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == gerenciarSeries.getjButtonSalvar()){
            gravaDados();
        }
        if(e.getSource() == gerenciarSeries.getjButtonAlterar()){
            edit = true;
            editaDados();
        }
        if(e.getSource()== gerenciarSeries.getjButtonExcluir()){
            
        }
    }
            
    
}
