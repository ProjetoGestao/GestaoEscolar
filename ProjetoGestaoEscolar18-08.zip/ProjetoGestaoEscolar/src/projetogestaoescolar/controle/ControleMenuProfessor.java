/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import projetogestaoescolar.GerenciarAlunos;
import projetogestaoescolar.MenuProfessor;

/**
 *
 * @author Gustavo
 */
public class ControleMenuProfessor implements ActionListener {
    MenuProfessor menuProfessor;
    
    public ControleMenuProfessor(){
        carregaTelas();
        adicionaEventos();
    }
    
    private void carregaTelas(){
        menuProfessor  = new MenuProfessor();
        menuProfessor.setVisible(true);
    }
    
    private void adicionaEventos(){
        menuProfessor.getjButtonDiarioDeClasse().addActionListener(this);
        menuProfessor.getjButtonAlterarFaltas().addActionListener(this);
        menuProfessor.getjButtonLançarFaltas().addActionListener(this);
        menuProfessor.getjButtonLançasNotas().addActionListener(this);
        menuProfessor.getjButtonLogoff().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == menuProfessor.getjButtonAlterarFaltas()){
            
        }
        if(e.getSource() == menuProfessor.getjButtonDiarioDeClasse()){
            
        }
        if(e.getSource() == menuProfessor.getjButtonLançarFaltas()){
            
        }
        if(e.getSource() == menuProfessor.getjButtonLançasNotas()){
            
        }
        if(e.getSource() == menuProfessor.getjButtonLogoff()){
            
    }
            
}
}
