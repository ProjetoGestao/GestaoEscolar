/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.modelo;
import javax.swing.JTextField;
import projetogestaoescolar.GerenciarPeriodo;

/**
 *
 * @author Gustavo
 */
public class GerenciamentoDePeriodo {
    Periodo periodo;
    int receberIdPeriodo;
    String idPeriodo;
    int receberAno;
    String ano;
    int receberDiasLetivos;
    String diasLetivos;
    public void salvar(GerenciarPeriodo gerenciarPeriodo){
        idPeriodo = gerenciarPeriodo.getjTextField1().getText();
        receberIdPeriodo = Integer.parseInt(idPeriodo);
        periodo.setIdPeriodo(receberIdPeriodo);
        ano = gerenciarPeriodo.getjTextField2().getText();
        receberAno = Integer.parseInt(ano);
        periodo.setAno(receberAno);
        diasLetivos = gerenciarPeriodo.getjTextFieldQuantDias().getText();
        receberDiasLetivos = Integer.parseInt(diasLetivos);
        periodo.setDiasLetivos(receberDiasLetivos);
        
     }
    
}
