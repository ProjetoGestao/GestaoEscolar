/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import projetogestaoescolar.GerenciamentoDeDisciplinas;

/**
 *
 * @author Gustavo
 */
public class ControleGerenciarDisciplinas implements ActionListener {
    GerenciamentoDeDisciplinas gerenciamentoDeDisciplinas;
    
    public ControleGerenciarDisciplinas(){
        carregaTelas();
        adicionaEventos();
    }
    
    private void carregaTelas(){
        gerenciamentoDeDisciplinas = new GerenciamentoDeDisciplinas();
        gerenciamentoDeDisciplinas.setVisible(true);
    }
    
    public void adicionaEventos(){
        gerenciamentoDeDisciplinas.getjButtonCadastrar().addActionListener(this);
        gerenciamentoDeDisciplinas.getjButtonAlterar().addActionListener(this);
        gerenciamentoDeDisciplinas.getjButtonExcluir().addActionListener(this);
        gerenciamentoDeDisciplinas.getjButtonSalvar().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == gerenciamentoDeDisciplinas.getjButtonCadastrar()){
            
        }
        if(e.getSource() == gerenciamentoDeDisciplinas.getjButtonAlterar()){
            
        }
        if(e.getSource() == gerenciamentoDeDisciplinas.getjButtonSalvar()){
            
        }
        if(e.getSource() == gerenciamentoDeDisciplinas.getjButtonExcluir()){
            
        }
            
    }
    
}
