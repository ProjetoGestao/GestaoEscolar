/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import projetogestaoescolar.GerenciarPeriodo;

/**
 *
 * @author Gustavo
 */
public class ControleGerenciarPeriodos implements ActionListener {
    GerenciarPeriodo gerenciarPeriodo;
    
    public ControleGerenciarPeriodos(){
        carregaTelas();
        adicionaEventos();
    }
    
    private void carregaTelas(){
        gerenciarPeriodo = new GerenciarPeriodo();
        gerenciarPeriodo.setVisible(true);
    }

    private void adicionaEventos(){
        gerenciarPeriodo.getjButtonSalvar().addActionListener(this);
        gerenciarPeriodo.getjButtonAlterar().addActionListener(this);
        gerenciarPeriodo.getjButtonExcluir().addActionListener(this);
    
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == gerenciarPeriodo.getjButtonSalvar()){
            
        }
        if(e.getSource() == gerenciarPeriodo.getjButtonAlterar()){
            
        }
        if(e.getSource() == gerenciarPeriodo.getjButtonExcluir()){
            
        }
            
    }
    

    
    
}
