/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import projetogestaoescolar.GerenciarAlunos;

/**
 *
 * @author Gustavo
 */
public class ControleGerenciarAlunos implements ActionListener {
    GerenciarAlunos gerenciarAlunos;
    
    public ControleGerenciarAlunos(){
        carregaTelas();
        adicionaEventos();
    }
    
    private void carregaTelas(){
        gerenciarAlunos = new GerenciarAlunos();
        gerenciarAlunos.setVisible(true);
    }
    
    private void adicionaEventos(){
       gerenciarAlunos.getjButtonCadastrar().addActionListener(this);
       gerenciarAlunos.getjButtonAlterar().addActionListener(this);
       gerenciarAlunos.getjButtonSalvar().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == gerenciarAlunos.getjButtonCadastrar()){
            
        }
        if(e.getSource() == gerenciarAlunos.getjButtonAlterar()){
            
        }
        if(e.getSource() == gerenciarAlunos.getjButtonSalvar()){
            
        }
    }
}
