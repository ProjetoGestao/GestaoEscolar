/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import projetogestaoescolar.GerenciamentoDeContas;

/**
 *
 * @author Gustavo
 */
public class ControleGerenciarContas implements ActionListener{
    GerenciamentoDeContas gerenciamentoDeContas;
    
    public ControleGerenciarContas(){
        carregaTelas();
        adicionaEventos();
    }
    
    private void carregaTelas(){
        gerenciamentoDeContas = new GerenciamentoDeContas();
        gerenciamentoDeContas.setVisible(true);
    }
    
    private void adicionaEventos(){
        gerenciamentoDeContas.getjButtonCadastrar().addActionListener(this);
        gerenciamentoDeContas.getjButtonAlterar().addActionListener(this);
        gerenciamentoDeContas.getjButtonExcluir().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == gerenciamentoDeContas.getjButtonCadastrar()){
            
        }
        if(e.getSource() == gerenciamentoDeContas.getjButtonAlterar()){
            
        }
        if(e.getSource() == gerenciamentoDeContas.getjButtonExcluir()){
            
        }
    }
    
    
}
