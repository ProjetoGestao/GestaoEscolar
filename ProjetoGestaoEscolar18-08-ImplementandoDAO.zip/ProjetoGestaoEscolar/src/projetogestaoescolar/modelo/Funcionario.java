/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.modelo;

/**
 *
 * @author Gustavo
 */
public class Funcionario extends Pessoa {
    protected int cpfDependente;
    protected int reDependente;
    protected int telDependente;
    protected String funcao;
    protected int nMatricula;

    public int getCpfDependente() {
        return cpfDependente;
    }

    public void setCpfDependente(int cpfDependente) {
        this.cpfDependente = cpfDependente;
    }

    public int getReDependente() {
        return reDependente;
    }

    public void setReDependente(int reDependente) {
        this.reDependente = reDependente;
    }

    public int getTelDependente() {
        return telDependente;
    }

    public void setTelDependente(int telDependente) {
        this.telDependente = telDependente;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public int getnMatricula() {
        return nMatricula;
    }

    public void setnMatricula(int nMatricula) {
        this.nMatricula = nMatricula;
    }
    
}
