/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import projetogestaoescolar.GeraçãoDeBoletins;
import projetogestaoescolar.MenuPrincipal;
import projetogestaoescolar.TelaLogin;

/**
 *
 * @author Gustavo
 */
public class ControleLogin implements ActionListener {
    private TelaLogin telaLogin;
    private MenuPrincipal menuPrincipal;
    
    public ControleLogin(TelaLogin telaLogin, MenuPrincipal menuPrincipal){
        this.telaLogin = telaLogin;
        this.menuPrincipal = menuPrincipal; 
        
        adicionaEventos();
    }

    ControleLogin(GeraçãoDeBoletins geraçãoDeBoletins) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private void adicionaEventos() {
        telaLogin.getjButtonLogin().addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource() == telaLogin.getjButtonLogin()){
            validaAcesso();
        }
        
    }
    
    private void validaAcesso() {
      if(telaLogin.validaCampos()==true){  
        if(telaLogin.getjTextFieldNomeDeUsuario().getText().equalsIgnoreCase("admin") &&
             telaLogin.getjPasswordFieldSenha().getText().equalsIgnoreCase("admin")){
            JOptionPane.showMessageDialog(null, "Bem Vindo");
            telaLogin.setVisible(false);
        } else{
            JOptionPane.showMessageDialog(null, "Acesso Negado");
        }
      }
    }
    

    
    
}
