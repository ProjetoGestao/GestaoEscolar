/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import projetogestaoescolar.GerenciarSeries;
import projetogestaoescolar.MenuPrincipal;

/**
 *
 * @author Gustavo
 */
public class ControleGerenciarSeries  implements ActionListener{
    GerenciarSeries gerenciarSeries;
    
    public ControleGerenciarSeries(MenuPrincipal menuPrincipal){
        carregaTelas(menuPrincipal);
        adicionaEventos();
    }
    
    private void carregaTelas(MenuPrincipal menuPrincipal){
        gerenciarSeries  = new GerenciarSeries(menuPrincipal,true);
        gerenciarSeries.setVisible(true);
    }
    
    private void adicionaEventos(){
        gerenciarSeries.getjButtonSalvar().addActionListener(this);
        gerenciarSeries.getjButtonAlterar().addActionListener(this);
        gerenciarSeries.getjButtonExcluir().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == gerenciarSeries.getjButtonSalvar()){
            
        }
        if(e.getSource() == gerenciarSeries.getjButtonAlterar()){
            
        }
        if(e.getSource()== gerenciarSeries.getjButtonExcluir()){
            
        }
    }
            
    
}
