/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import projetogestaoescolar.GeraçãoDeBoletins;

/**
 *
 * @author Gustavo
 */
public class ControleGerarBoletins implements ActionListener {
       private GeraçãoDeBoletins geraçãoDeBoletins;
       
        public ControleGerarBoletins(){
        carregaTelas();
        adicionaEventos();
    }
    
    private void carregaTelas(){
        geraçãoDeBoletins = new GeraçãoDeBoletins();
        geraçãoDeBoletins.setVisible(true);
    }

    public void adicionaEventos(){
        geraçãoDeBoletins.getjButtonPesquisar().addActionListener(this);
        geraçãoDeBoletins.getjButtonExcluir().addActionListener(this);
        geraçãoDeBoletins.getjButtonAlterar().addActionListener(this);
        
    }
    
       @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == geraçãoDeBoletins.getjButtonPesquisar()){
            
    }
        if(e.getSource() == geraçãoDeBoletins.getjButtonAlterar()){
            
    }   
        if(e.getSource() == geraçãoDeBoletins.getjButtonExcluir()){
            
    }
       
}
}
