/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.modelo;

/**
 *
 * @author carry
 */
public class Disciplina {
    String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQuantidadeDeAula() {
        return quantidadeDeAula;
    }

    public void setQuantidadeDeAula(int quantidadeDeAula) {
        this.quantidadeDeAula = quantidadeDeAula;
    }

    public int getIdCodigo() {
        return idCodigo;
    }

    public void setIdCodigo(int idCodigo) {
        this.idCodigo = idCodigo;
    }
    int quantidadeDeAula;
    int idCodigo;
    
    
    
}
