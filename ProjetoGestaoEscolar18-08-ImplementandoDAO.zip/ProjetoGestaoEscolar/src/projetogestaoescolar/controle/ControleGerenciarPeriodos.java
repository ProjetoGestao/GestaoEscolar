/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import projetogestaoescolar.GerenciarPeriodo;
import projetogestaoescolar.modelo.GerenciamentoDePeriodo;
import projetogestaoescolar.modelo.Periodo;
import projetogestaoescolarDao.PeriodoDAO;

/**
 *
 * @author Gustavo
 */
public class ControleGerenciarPeriodos implements ActionListener {
    GerenciarPeriodo gerenciarPeriodo;
    GerenciamentoDePeriodo gerenciamento;
    PeriodoDAO dao; 
        
    public ControleGerenciarPeriodos(GerenciarPeriodo gerenciarPeriodo){
        carregaTelas();
        adicionaEventos();
        gerenciamento = new GerenciamentoDePeriodo(gerenciarPeriodo);
        GerenciarPeriodo tela = gerenciarPeriodo;
        
    }
    
    private void carregaTelas(){
        gerenciarPeriodo = new GerenciarPeriodo();
        gerenciarPeriodo.setVisible(true);
        gerenciamento.listar(gerenciarPeriodo);
    }

    private void adicionaEventos(){
        gerenciarPeriodo.getjButtonSalvar().addActionListener(this);
        gerenciarPeriodo.getjButtonAlterar().addActionListener(this);
        gerenciarPeriodo.getjButtonExcluir().addActionListener(this);
    
    }
    
  
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == gerenciarPeriodo.getjButtonSalvar()){
            gerenciamento.salvar(gerenciarPeriodo);
        }
        if(e.getSource() == gerenciarPeriodo.getjButtonAlterar()){
            
        }
        if(e.getSource() == gerenciarPeriodo.getjButtonExcluir()){
            
        }
            
    }
    

    
    
}
