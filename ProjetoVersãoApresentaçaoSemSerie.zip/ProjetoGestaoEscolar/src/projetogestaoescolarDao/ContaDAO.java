/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolarDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import projetogestaoescolar.GerenciamentoDeContas;
import projetogestaoescolar.modelo.Conta;
import projetogestaoescolar.modelo.Periodo;


/**
 *
 * @author mpire
 */
public class ContaDAO {
    
    private Connection conexao;

    public ContaDAO(Connection conexao) {
        this.conexao = conexao;
    }
    
    public void adiciona(GerenciamentoDeContas tela, Conta conta){
        
    //    String nome;
    //    String usuario;
    //    String senha;
    //    String cargo;
        
        String sql = "insert into conta (nome,usuario,senha,cargo) values (?,?,?,?)";
        
        try{
            PreparedStatement pst = conexao.prepareStatement(sql);
            pst.setString(1, conta.getNome());
            pst.setString(2, conta.getUsuario());
            pst.setString(3, conta.getSenha());
            pst.setString(4, conta.getCargo());
            pst.execute();
            pst.close();
            JOptionPane.showMessageDialog(null, "Usuário cadastrado com sucesso.");
            tela.limpaTela();
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Não foi possivel inserir.");
            throw new RuntimeException(e);
        }
        
    }
    
    public List<Conta> lista(){    
        String sql = "select * from conta order by cargo";
        List<Conta> listaContas = new ArrayList<Conta>();
        try{
            PreparedStatement pst = conexao.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                Conta conta = new Conta();
                conta.setNome(rs.getString("nome"));
                conta.setUsuario(rs.getString("usuario"));
                conta.setCargo(rs.getString("cargo"));
                listaContas.add(conta);
            }
            rs.close();
            pst.close();
            return listaContas;
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Erro ao listar.");
            throw new RuntimeException(e);
        }
                
    }
    
    public Conta busca(String usuario) throws SQLException{
        
        String sql = "select * from conta where usuario = '"+usuario+"'";
        
        Conta conta = new Conta();         
              
        PreparedStatement pst = conexao.prepareStatement(sql);
        ResultSet rst = pst.executeQuery();
        while(rst.next()){
            conta.setNome(rst.getString("nome"));
            conta.setUsuario(rst.getString("usuario"));   
            conta.setSenha(rst.getString("senha"));
            conta.setCargo(rst.getString("cargo"));
        }
        rst.close();
        pst.close();
        
        return conta;
        
    }
    
    public boolean exclui(String usuario){   
        boolean result = false;
        String sql = "delete from conta where usuario = '"+usuario+"'";       
        try{
            PreparedStatement pst = conexao.prepareStatement(sql);
            result = pst.execute();
            result = true;
            return result;
        } catch (SQLException e){
            throw new RuntimeException(e);
        } 
        
    }

    public void alterar(GerenciamentoDeContas tela, Conta c) {
        String sql = "update conta set nome = '"+c.getNome()+"', senha = '"+c.getSenha()+"', cargo = '"+c.getCargo()+"' where usuario = '"+c.getUsuario()+"'";       
        try{
            Conta conta = busca(c.getUsuario());
           
            PreparedStatement pst = conexao.prepareStatement(sql);
            pst.execute();
            pst.close();
            JOptionPane.showMessageDialog(null,"Usuário alterado com sucesso!");
            tela.limpaTela();
            tela.getjTextField2().enable();
            
            
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null,"Não foi possível alterar.");
        }
    }
    
}
