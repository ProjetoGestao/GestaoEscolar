/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import projetogestaoescolar.GerenciamentoDeContas;
import projetogestaoescolar.GerenciarPeriodo;
import projetogestaoescolarDao.ContaDAO;

/**
 *
 * @author mpire
 */
public class GerenciaDeConta {
    
    GerenciamentoDeContas tela;
    Conta conta;
    ContaDAO dao;
    boolean edit;
    
    public GerenciaDeConta(Connection conexao, GerenciamentoDeContas tela){
        this.tela = tela;
        conta = new Conta();
        dao = new  ContaDAO(conexao);
        modelo = (DefaultTableModel)tela.getjTable1().getModel();
    }
    
    private DefaultTableModel modelo;

    
    public void salvar(){
        if (edit == false){
            conta.nome = tela.getjTextField1().getText();
            conta.usuario = tela.getjTextField2().getText();
            conta.senha = tela.getjPasswordField1().getText();
            if (tela.getjComboBox1().getSelectedIndex() == 0){
                conta.cargo = "diretor";
            }
            if (tela.getjComboBox1().getSelectedIndex() == 1){
                conta.cargo = "pedagogo";
            }
            if (tela.getjComboBox1().getSelectedIndex() == 2){
                conta.cargo = "secretario";
            }
            if (tela.getjComboBox1().getSelectedIndex() == 3){
                conta.cargo = "professor";
            }
            if (tela.getjPasswordField1().getText().equals(tela.getjPasswordField2().getText())){
                dao.adiciona(tela, conta);
            }else{
                JOptionPane.showMessageDialog(tela, "Campos [SENHA] e [REPITA A SENHA] não correspondem!");
            }   
        }else{
            conta.nome = tela.getjTextField1().getText();
            conta.usuario = tela.getjTextField2().getText();
            conta.senha = tela.getjPasswordField1().getText();
            if (tela.getjComboBox1().getSelectedIndex() == 0){
                conta.cargo = "diretor";
            }
            if (tela.getjComboBox1().getSelectedIndex() == 1){
                conta.cargo = "pedagogo";
            }
            if (tela.getjComboBox1().getSelectedIndex() == 2){
                conta.cargo = "secretario";
            }
            if (tela.getjComboBox1().getSelectedIndex() == 3){
                conta.cargo = "professor";
            }
            if (tela.getjPasswordField1().getText().equals(tela.getjPasswordField2().getText())){
                dao.alterar(tela, conta);
            }else{
                JOptionPane.showMessageDialog(tela, "Campos [SENHA] e [REPITA A SENHA] não correspondem!");
            }
        edit = false;
        }
     }
    
    public void listar(){
        limpaTabela();   
        List<Conta> listaContas = dao.lista();
        for(int i=0;i<listaContas.size();i++){
            addTabela(
                    listaContas.get(i).getNome(),
                    listaContas.get(i).getUsuario(),
                    listaContas.get(i).getCargo()
                    );
        }
    }
    
    public void excluir() {
        int item = tela.itemSelecionado();
        if(item >= 0){      
          String usuario = modelo.getValueAt(item, 1).toString();         
          int op = JOptionPane.showConfirmDialog(tela, "Deseja excluir o usuario ["+usuario+"]?", "Confirmação", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null);
          if (op == 0){
              modelo.removeRow(item);
              boolean result = dao.exclui(usuario);
              if (result){
                  JOptionPane.showMessageDialog(tela, "Excluído com sucesso.");
              }
          }
        } 
    }
    
    private void limpaTabela(){
        int linhas = modelo.getRowCount();
        for(int i=0;i<linhas;i++){
            modelo.removeRow(0);
        }
    }
    
    public final void addTabela(Object... objects) {
        modelo.addRow(objects);
    }

    public void editar() throws SQLException {
        int item = tela.itemSelecionado();
        if(item>=0){
            Conta conta;
            String usuario = modelo.getValueAt(item, 1).toString();
            conta = dao.busca(usuario);
            tela.getjTextField1().setText(conta.getNome());
            tela.getjTextField2().setText(conta.getUsuario());
            tela.getjTextField2().disable();
            tela.getjPasswordField1().setText(conta.getSenha());
            tela.getjPasswordField2().setText(conta.getSenha());
            if (conta.cargo.equals("diretor")){
                tela.getjComboBox1().setSelectedIndex(0);
            }
            if (conta.cargo.equals("pedagogo")){
                tela.getjComboBox1().setSelectedIndex(1);
            }
            if (conta.cargo.equals("secretario")){
                tela.getjComboBox1().setSelectedIndex(2);
            }
            if (conta.cargo.equals("professor")){
                tela.getjComboBox1().setSelectedIndex(3);
            }
            edit = true;
        }
    }
    
}
