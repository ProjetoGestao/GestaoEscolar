/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.modelo;

/**
 *
 * @author Gustavo
 */
public class Aluno extends Pessoa {
    protected int cpfResponsavel;
    protected int rgResponsavel;
    protected int telefoneResponsavel;
    protected int nMatricula;

    public int getCpfResponsavel() {
        return cpfResponsavel;
    }

    public void setCpfResponsavel(int cpfResponsavel) {
        this.cpfResponsavel = cpfResponsavel;
    }

    public int getRgResponsavel() {
        return rgResponsavel;
    }

    public void setRgResponsavel(int rgResponsavel) {
        this.rgResponsavel = rgResponsavel;
    }

    public int getTelefoneResponsavel() {
        return telefoneResponsavel;
    }

    public void setTelefoneResponsavel(int telefoneResponsavel) {
        this.telefoneResponsavel = telefoneResponsavel;
    }

    public int getnMatricula() {
        return nMatricula;
    }

    public void setnMatricula(int nMatricula) {
        this.nMatricula = nMatricula;
    }
    
}
