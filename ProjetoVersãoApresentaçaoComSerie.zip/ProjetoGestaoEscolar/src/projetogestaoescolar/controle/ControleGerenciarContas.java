/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import projetogestaoescolar.GerenciamentoDeContas;
import projetogestaoescolar.GerenciarPeriodo;
import projetogestaoescolar.modelo.GerenciaDeConta;
import projetogestaoescolar.modelo.GerenciamentoDePeriodo;
import projetogestaoescolarDao.PeriodoDAO;

/**
 *
 * @author Gustavo
 */
public class ControleGerenciarContas implements ActionListener{
    GerenciamentoDeContas gerenciamentoDeContas;
    GerenciaDeConta gerenciaDeConta; 
    private Connection conexao;

    
    public ControleGerenciarContas(Connection conexao){
        this.conexao = conexao;
        carregaTelas();
        adicionaEventos();
    }
    
    private void carregaTelas(){
        gerenciamentoDeContas = new GerenciamentoDeContas();
        gerenciamentoDeContas.setVisible(true);
        gerenciaDeConta = new GerenciaDeConta(conexao, gerenciamentoDeContas);
        gerenciaDeConta.listar();
    }
    
    private void adicionaEventos(){
        gerenciamentoDeContas.getjButtonCadastrar().addActionListener(this);
        gerenciamentoDeContas.getjButtonAlterar().addActionListener(this);
        gerenciamentoDeContas.getjButtonExcluir().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == gerenciamentoDeContas.getjButtonCadastrar()){
            gerenciaDeConta.salvar();
            gerenciaDeConta.listar();
        }
        if(e.getSource() == gerenciamentoDeContas.getjButtonAlterar()){
            try {
                gerenciaDeConta.editar();
            } catch (SQLException ex) {
            }
        }
        if(e.getSource() == gerenciamentoDeContas.getjButtonExcluir()){
            gerenciaDeConta.excluir();
        }
    }
    
    
}
