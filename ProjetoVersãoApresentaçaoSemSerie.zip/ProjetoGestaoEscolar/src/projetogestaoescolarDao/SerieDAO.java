/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolarDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import projetogestaoescolar.GerenciarSeries;
import projetogestaoescolar.modelo.Serie;

/**
 *
 * @author gustavo.martins
 */
public class SerieDAO {
    private Connection conexao;
    private DefaultTableModel modelo;
    private int id;
    private GerenciarSeries gerenciar;
    private List<Serie> series;
    
    public SerieDAO(Connection conexao){
        this.conexao = conexao;
        series = new ArrayList<>();
    }
    
    public void adiciona(Serie serie){
        
        String sql = "insert into serie(ano, quantidadeDeTurmas, numeroDeTurmas)" + "values (?,?,?)";
        try{
            PreparedStatement pst = conexao.prepareStatement(sql);
            pst.setInt(1,serie.getAno());
            pst.setInt(2,serie.getQuantidadeDeTurmas());
            pst.setInt(3,serie.getnumeroDeTurmas());
            pst.execute();
            pst.close();
        }catch (SQLException e){
            JOptionPane.showMessageDialog(gerenciar,"Não foi possivel inserir");
            throw new RuntimeException(e);
        }
    }
    
     public List<Serie> getSerie() {
        return series;
    }
    
    public List<Serie> lista(){
        String sql = "select * from serie order by ano";
        List<Serie> listaSeries = new ArrayList<Serie>();
        try{
            PreparedStatement pst = conexao.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                Serie s = new Serie();
                s.setIdSerie(rs.getInt("idSerie"));
                s.setAno(rs.getInt("ano"));
                s.setQuantidadeDeTurmas(rs.getInt("quantidadeDeTurmas"));
                s.setNumeroDeTurmas(rs.getInt("numeroDeTurmas"));
                listaSeries.add(s);
            }
            rs.close();
            pst.close();
            return listaSeries;
        }catch(SQLException e){
            JOptionPane.showMessageDialog(gerenciar,"Erro ao listar!\n");
            throw new RuntimeException(e);
        }
    }
    
    public List<Serie> listaCombobox(){
        String sql = "select * from periodo order by ano";
        List<Serie> listaSeriesCombox = new ArrayList<Serie>();
        try{
            PreparedStatement pst = conexao.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
        while(rs.next()){
            Serie s = new Serie();
            s.setAno(rs.getInt("ano"));
            listaSeriesCombox.add(s);
        }   
        rs.close();
        pst.close();
        return listaSeriesCombox;
    }catch(SQLException e){
        JOptionPane.showMessageDialog(gerenciar,"Erro ao lista!");
        throw new RuntimeException(e);
    }
}
    
    public List<Serie> recuperarSeriePorNumero(int numero) throws SQLException {
        String sentencaSelect = "SELECT * FROM serie WHERE ano LIKE ?";
        PreparedStatement statementSelect = conexao.prepareStatement(sentencaSelect);
        ResultSet resultsetSelect = statementSelect.executeQuery();
        List<Serie> series = new ArrayList<Serie>();
        while (resultsetSelect.next()) {
            Serie s = new Serie();
            s.setIdSerie(resultsetSelect.getInt("IdSerie"));
            s.setAno(resultsetSelect.getInt("anoLetivo"));
            series.add(s);
        }
        resultsetSelect.close();
        statementSelect.close();
        return series;
    }
    
    
    public Serie busca(int id) throws SQLException{
        
        String sql = "select * from serie where id = ?";
        
        Serie serie = new Serie();
        
        PreparedStatement pst = conexao.prepareStatement(sql);
        pst.setInt(1,id);
        ResultSet rst = pst.executeQuery();
        while(rst.next()){
            serie.setAno(rst.getInt("ano"));
            serie.setQuantidadeDeTurmas(rst.getInt("quantidadeDeTurmas"));
            serie.setNumeroDeTurmas(rst.getInt("numeroDeTurmas"));
        }
        rst.close();
        pst.close();
        return serie;
    }
    
    // continuar com o alterar
    public void alterar(Serie serie ){
        String sql = "uptade serie set ano = ?, quantidadeDeTurmas = ?, numeroDeTurmas = ? where id = ?";
        
        try{
            
            if(serie.getIdSerie()>=0){
                PreparedStatement pst = conexao.prepareStatement(sql);
                pst.setInt(1, serie.getAno());
                pst.setInt(2, serie.getQuantidadeDeTurmas());
                pst.setInt(3, serie.getnumeroDeTurmas());
                pst.setInt(4, serie.getIdSerie());
                pst.execute();
                pst.close();
            }
            else{
                System.out.print("Não é possivel alterar!");
            }
    }catch (SQLException e){
        throw new RuntimeException(e);
    }
            
   
}
    
    
}
