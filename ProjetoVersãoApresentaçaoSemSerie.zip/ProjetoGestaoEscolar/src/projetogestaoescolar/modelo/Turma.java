package projetogestaoescolar.modelo;

public class Turma {
    
    int idTurma;
    String nome;
    String serie;
    String periodoLetivo;

    public Turma(String nome, String serie, String periodoLetivo) {
        this.nome = nome;
        this.serie = serie;
        this.periodoLetivo = periodoLetivo;
    }

    public Turma(int idTurma, String nome, String serie, String periodoLetivo) {
        this.idTurma = idTurma;
        this.nome = nome;
        this.serie = serie;
        this.periodoLetivo = periodoLetivo;
    }

    public int getIdTurma() {
        return idTurma;
    }

    public String getNome() {
        return nome;
    }

    public String getSerie() {
        return serie;
    }

    public String getPeriodoLetivo() {
        return periodoLetivo;
    }

    public void setIdTurma(int idTurma) {
        this.idTurma = idTurma;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public void setPeriodoLetivo(String periodoLetivo) {
        this.periodoLetivo = periodoLetivo;
    }
    
}
