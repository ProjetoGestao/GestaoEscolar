/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolarDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import projetogestaoescolar.GerenciarPeriodo;
import projetogestaoescolar.modelo.Periodo;

/**
 *
 * @author gustavo.martins
 */
public class PeriodoDAO {
     private Connection conexao;
     private DefaultTableModel modelo;
    private int id;
    private GerenciarPeriodo gerenciarPeriodo;
    
    public PeriodoDAO(Connection conexao){
        this.conexao = conexao;
    }
    
    public void adiciona(Periodo periodo){
        
        String sql = "insert into periodo (idperiodo,ano,diasLetivos) "
                + "values (?,?,?)";
        
        try{
            PreparedStatement pst = conexao.prepareStatement(sql);
            pst.setInt(1, periodo.getIdPeriodo());
            pst.setInt(2, periodo.getAno());
            pst.setInt(1, periodo.getDiasLetivos());
            pst.execute();
            pst.close();
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Não foi possivel inserir.");
            throw new RuntimeException(e);
        }
        
    }
    
    public List<Periodo> lista(){    
        String sql = "select * from pessoa order by nome";
        List<Periodo> listaPeriodos = new ArrayList<Periodo>();
        try{
            PreparedStatement pst = conexao.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                Periodo p = new Periodo();
                p.setIdPeriodo(rs.getInt("IdPeriodo"));
                p.setAno(rs.getInt("ano"));    
                p.setDiasLetivos(rs.getInt("diasLetivos"));
                listaPeriodos.add(p);
            }
            rs.close();
            pst.close();
            return listaPeriodos;
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Erro ao listar.");
            throw new RuntimeException(e);
        }
        
    }
    
    private void editaDados() {
        int item = gerenciarPeriodo.itemSelecionado();
        if(item >= 0){
          gerenciarPeriodo.getjTextField1().setText(modelo.getValueAt(item, 1).toString());
          gerenciarPeriodo.getjTextField2().setText(modelo.getValueAt(item, 2).toString());
          gerenciarPeriodo.getjTextFieldQuantDias().setText(modelo.getValueAt(item, 2).toString());
          this.id = Integer.parseInt(modelo.getValueAt(item, 0).toString());
        } 
    }
    
    
    public Periodo busca(int id) throws SQLException{
        
        String sql = "select * from pessoa where id = ?";
        
        Periodo periodo = new Periodo();         
              
        PreparedStatement pst = conexao.prepareStatement(sql);
        pst.setInt(1, id);
        ResultSet rst = pst.executeQuery();
        while(rst.next()){                       
            periodo.setIdPeriodo(rst.getInt("idperiodo"));
            periodo.setAno(rst.getInt("ano"));   
            periodo.setDiasLetivos(rst.getInt("diasLetivos"));
        }
        rst.close();
        pst.close();
        return periodo;
        
    }
    
    public boolean exclui(int id){
        
        boolean result = false;
        String sql = "delete from pessoa where id = ?";       
        try{
            Periodo periodo = busca(id);
            if(periodo.getIdPeriodo()>0){
                PreparedStatement pst = conexao.prepareStatement(sql);
                pst.setInt(1, id);
                result = pst.execute();               
                pst.close();
            } else{
                System.out.println("Não foi possível excluir.");
            }
            
            return result;
        } catch (SQLException e){
            throw new RuntimeException(e);
        } 
        
    }
    
    public void altera(Periodo p){
        
        String sql = "update pessoa set nome = ?, cpf = ? where id = ?";       
        try{
            Periodo periodo = busca(p.getIdPeriodo());
            if(periodo.getIdPeriodo()>0){
                PreparedStatement pst = conexao.prepareStatement(sql);
                pst.setInt(1, p.getIdPeriodo());
                pst.setInt(2, p.getAno());
                pst.setInt(3, p.getIdPeriodo());
                pst.execute();
                pst.close();
            } else{
                System.out.println("Não foi possível alterar.");
            }
            
        } catch (SQLException e){
            throw new RuntimeException(e);
        }
        
    }
    
    
    
}
