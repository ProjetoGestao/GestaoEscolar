package projetogestaoescolar.modelo;

public class Serie {
    int idSerie;
    int ano; // 1 (primeiro ano) , 2 (segundo ano) ...
    int quantidadeDeTurmas;
    int numeroDeTurmas; // fundamental, médio..
    
    public Serie(int ano, int quantidadeDeTurmas, int numeroDeTurmas) {
        this.ano = ano;
        this.quantidadeDeTurmas = quantidadeDeTurmas;
        this.numeroDeTurmas = numeroDeTurmas;
    }
    
    public Serie(){
        
    }
    
    public void setIdSerie(int idSerie){
        this.idSerie = idSerie;
    }
    public int getIdSerie(){
        return idSerie;
    }
    public void setAno(int ano) {
        this.ano = ano;
    }

    public void setQuantidadeDeTurmas(int quantidadeDeTurmas) {
        this.quantidadeDeTurmas = quantidadeDeTurmas;
    }

    public void setNumeroDeTurmas(int numeroDeTurmas) {
        this.numeroDeTurmas = numeroDeTurmas;
    }

    public int getAno() {
        return ano;
    }

    public int getQuantidadeDeTurmas() {
        return quantidadeDeTurmas;
    }

    public int getnumeroDeTurmas() {
        return numeroDeTurmas;
    }
    
}
