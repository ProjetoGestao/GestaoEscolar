/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import projetogestaoescolar.GerenciarFuncionario;

/**
 *
 * @author Gustavo
 */
public class ControleGerenciarFuncionario implements ActionListener {
    GerenciarFuncionario gerenciarFuncionario;
    
    public ControleGerenciarFuncionario(){
        carregaTelas();
        adicionaEventos();
    }
    
    private void carregaTelas(){
        gerenciarFuncionario = new GerenciarFuncionario();
        gerenciarFuncionario.setVisible(true);
    }
    private void adicionaEventos(){
        gerenciarFuncionario.getjButtonCadastrar().addActionListener(this);
        gerenciarFuncionario.getjButtonAlterar().addActionListener(this);
        gerenciarFuncionario.getjButtonSalvar().addActionListener(this);
        gerenciarFuncionario.getjButtonExcluir().addActionListener(this);
    }
     
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == gerenciarFuncionario.getjButtonCadastrar()){
            
        }
        if(e.getSource() == gerenciarFuncionario.getjButtonAlterar()){
            
        }
        if(e.getSource() == gerenciarFuncionario.getjButtonSalvar()){
            
        }
        if(e.getSource() == gerenciarFuncionario.getjButtonExcluir()){
            
        }
    }
    
}
