/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import projetogestaoescolar.Conexao;
import projetogestaoescolar.MenuPrincipal;
import projetogestaoescolar.TelaLogin;
import projetogestaoescolar.modelo.GerenciamentoDePeriodo;

/**
 *
 * @author Gustavo
 */
public class ControlePrincipal implements ActionListener{
    private MenuPrincipal menuPrincipal;
    private TelaLogin telaLogin;
    private ControleLogin controleLogin;
    private Connection conexao;
    
    
    public ControlePrincipal(){
        carregaTelas();
        adicionaEventos();
        conexao = Conexao.getConexao();
        controleLogin = new ControleLogin(telaLogin,menuPrincipal,conexao);
        menuPrincipal.setVisible(true);
        telaLogin.show();
        
    }
    
    private void carregaTelas(){
        menuPrincipal = new MenuPrincipal();
        telaLogin = new TelaLogin(menuPrincipal, true);
    }
    
    private void adicionaEventos() {
        menuPrincipal.getjButtonGerarBoletins().addActionListener(this);
        menuPrincipal.getjButtonGerenciarAlunos().addActionListener(this);
        menuPrincipal.getjButtonGerenciarDisciplinas().addActionListener(this);
        menuPrincipal.getjButtonGerenciarFuncionarios().addActionListener(this);
        menuPrincipal.getjButtonGerenciarPeriodos().addActionListener(this);
        menuPrincipal.getjButtonGerenciarSeries().addActionListener(this);
        menuPrincipal.getjButtonTransferirAlunos().addActionListener(this);
        menuPrincipal.getjButtonSair().addActionListener(this);
        menuPrincipal.getjButtonGerenciarContas().addActionListener(this);
 
    }

    //Não consegui entender essa chamada no action performed    
     @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource() == menuPrincipal.getjButtonGerarBoletins()){
           ControleGerarBoletins controleGerarBoletins = new ControleGerarBoletins();
        }
        if(e.getSource() == menuPrincipal.getjButtonGerenciarAlunos()){
            ControleGerenciarAlunos controleGerenciarAlunos = new ControleGerenciarAlunos();     
        }
        if(e.getSource() == menuPrincipal.getjButtonGerenciarContas()){
           ControleGerenciarContas controleGerenciarContas = new ControleGerenciarContas(conexao);
        }
        if(e.getSource() == menuPrincipal.getjButtonGerenciarDisciplinas()){
           ControleGerenciarDisciplinas controleGerenciarDisciplinas= new ControleGerenciarDisciplinas();
        }
        if(e.getSource() == menuPrincipal.getjButtonGerenciarFuncionarios()){
           ControleGerenciarFuncionario controleGerenciarFuncionario= new ControleGerenciarFuncionario();
        }
        if(e.getSource() == menuPrincipal.getjButtonGerenciarPeriodos()){
           ControleGerenciarPeriodos controleGerenciarPeriodos= new ControleGerenciarPeriodos(conexao);
        }
        if(e.getSource() == menuPrincipal.getjButtonGerenciarSeries()){
           ControleGerenciarSeries controleGerenciarSeries = new ControleGerenciarSeries(menuPrincipal,conexao);
        }
        if(e.getSource() == menuPrincipal.getjButtonTransferirAlunos()){
           ControleGerenciamentoDeTransferencias controleGerenciamentoDeTransferencias = new ControleGerenciamentoDeTransferencias();
        }
        if(e.getSource() == menuPrincipal.getjButtonSair()){
           System.exit(0);
        }
        
    }
    
    
}
