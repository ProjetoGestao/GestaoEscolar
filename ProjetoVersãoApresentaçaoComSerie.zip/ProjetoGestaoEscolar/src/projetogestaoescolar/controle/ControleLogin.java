/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetogestaoescolar.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import projetogestaoescolar.GeraçãoDeBoletins;
import projetogestaoescolar.MenuPrincipal;
import projetogestaoescolar.TelaLogin;
import projetogestaoescolarDao.ContaDAO;
import java.sql.Connection;
import java.util.Arrays;
import projetogestaoescolar.modelo.Conta;

/**
 *
 * @author Gustavo
 */
public class ControleLogin implements ActionListener {
    private TelaLogin telaLogin;
    private MenuPrincipal menuPrincipal;
    private String login;
    private String senha;
    private ContaDAO contaDao;
    private Connection conexao;
    
    
    public ControleLogin(TelaLogin telaLogin, MenuPrincipal menuPrincipal,Connection conexao){
        this.conexao = conexao;
        this.telaLogin = telaLogin;
        this.menuPrincipal = menuPrincipal; 
        this.contaDao = new ContaDAO(conexao);
        adicionaEventos();
    }

    
    
    private void adicionaEventos() {
        telaLogin.getjButtonLogin().addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource() == telaLogin.getjButtonLogin()){
            try {
                validaAcesso();
            } catch (SQLException ex) {
                Logger.getLogger(ControleLogin.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
    
    private void validaAcesso() throws SQLException {
      if(telaLogin.validaCampos()==true){  
        login = telaLogin.getjTextFieldNomeDeUsuario().getText();
        senha = telaLogin.getjPasswordFieldSenha().getText();
        try{
            Conta conta = contaDao.busca(login);
            if(conta.getUsuario().equals(login)){
                if(conta.getSenha().equals(senha)){
                    telaLogin.setVisible(false);
                } else{
                    JOptionPane.showMessageDialog(null, "Senha incorreta");
                }
            } else{
                JOptionPane.showMessageDialog(null, "Acesso Negado");
            }
      } catch(NullPointerException e){
          JOptionPane.showMessageDialog(null, "Acesso Negado");
      }
      }
    }
    

    
    
}
